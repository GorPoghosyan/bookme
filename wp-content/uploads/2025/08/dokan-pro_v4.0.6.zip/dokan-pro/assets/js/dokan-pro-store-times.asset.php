<?php return array('dependencies' => array(), 'version' => 'c3211a5c94b7bc42e07c');
