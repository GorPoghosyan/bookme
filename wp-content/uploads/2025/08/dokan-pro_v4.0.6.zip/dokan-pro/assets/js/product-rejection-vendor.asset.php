<?php return array('dependencies' => array(), 'version' => '21beba4d29efa4cf9446');
