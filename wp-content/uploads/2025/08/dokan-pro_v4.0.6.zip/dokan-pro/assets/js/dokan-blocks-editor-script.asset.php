<?php return array('dependencies' => array(), 'version' => 'd2cc437bb1ff3d3063a3');
