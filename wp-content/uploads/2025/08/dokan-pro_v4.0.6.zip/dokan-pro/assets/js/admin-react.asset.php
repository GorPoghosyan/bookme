<?php return array('dependencies' => array('lodash', 'react', 'wp-api-fetch', 'wp-hooks', 'wp-html-entities', 'wp-i18n', 'wp-url'), 'version' => '4307dc2b813bdc8e364b');
