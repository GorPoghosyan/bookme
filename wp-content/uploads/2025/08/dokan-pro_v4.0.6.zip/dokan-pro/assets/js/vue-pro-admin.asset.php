<?php return array('dependencies' => array('jquery'), 'version' => '692d76212d110f1399ea');
