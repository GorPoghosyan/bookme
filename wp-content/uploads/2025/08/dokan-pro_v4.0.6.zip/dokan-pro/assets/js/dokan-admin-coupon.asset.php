<?php return array('dependencies' => array(), 'version' => '2a0190fcec729b835907');
