<?php return array('dependencies' => array(), 'version' => '7ce37b588990543133ce');
