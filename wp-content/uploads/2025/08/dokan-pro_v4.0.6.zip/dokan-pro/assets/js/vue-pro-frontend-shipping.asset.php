<?php return array('dependencies' => array(), 'version' => '4701512ed9ede37b127a');
