<?php return array('dependencies' => array(), 'version' => 'b299e63b6f272f47a3f5');
