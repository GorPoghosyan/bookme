<?php return array('dependencies' => array('wp-api-fetch', 'wp-i18n'), 'version' => 'd4d40819fa075b61708a');
