<?php return array('dependencies' => array(), 'version' => '57c3faff3efc8972a6c1');
