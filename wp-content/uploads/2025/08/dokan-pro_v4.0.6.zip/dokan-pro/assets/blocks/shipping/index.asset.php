<?php return array('dependencies' => array('react', 'wc-blocks-checkout', 'wp-element', 'wp-plugins'), 'version' => '9549a5e6a15f8c27c7bb');
