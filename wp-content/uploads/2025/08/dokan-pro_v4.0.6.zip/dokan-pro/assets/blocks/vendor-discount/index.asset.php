<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '72a6f756c4e1a60a7152');
