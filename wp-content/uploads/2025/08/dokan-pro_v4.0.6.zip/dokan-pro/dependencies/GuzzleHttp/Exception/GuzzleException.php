<?php

namespace WeDevs\DokanPro\Dependencies\GuzzleHttp\Exception;

use WeDevs\DokanPro\Dependencies\Psr\Http\Client\ClientExceptionInterface;

interface GuzzleException extends ClientExceptionInterface
{
}
